package com.carrental.apigatewayzuul;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGatewayZuulApplicationTests {

	@Test
	void contextLoads() {
	}

}
