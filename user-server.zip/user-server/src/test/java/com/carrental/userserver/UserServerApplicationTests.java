package com.carrental.userserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
